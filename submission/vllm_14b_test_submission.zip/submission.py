# =============================================================================
# Starter kit: vLLM backend -- 14B model variant
# =============================================================================
# High-throughput inference. Requires a GPU. Edit the CONFIG block, then submit
# this file together with requirements.txt.
#
# Uses a 4-bit AWQ quantized 14B checkpoint. Weights alone are ~10 GB, which
# is tight on a 16 GB T4 once KV cache and activations are added -- so
# max_model_len is kept modest and gpu_memory_utilization is pushed up close
# to the practical ceiling. If you hit a CUDA OOM, lower MAX_MODEL_LEN first
# (context length has the biggest effect on KV cache size), then
# GPU_MEMORY_UTILIZATION if needed.
# =============================================================================
import os
import time

os.environ.setdefault("HF_HUB_ENABLE_HF_TRANSFER", "1")
os.environ.setdefault("HF_HUB_VERBOSITY", "info")

from vllm import LLM, SamplingParams
from transformers import AutoTokenizer

# ---- CONFIG -----------------------------------------------------------------
HF_REPO_ID = "Qwen/Qwen2.5-14B-Instruct-AWQ"
QUANTIZATION = "awq"          # None for unquantized fp16 repos
HF_TOKEN = ""                  # only for PRIVATE / gated repos
SYSTEM_PROMPT = "You are a helpful assistant. Answer concisely."
TEMPERATURE = 0.7
TOP_P = 0.9
MAX_NEW_TOKENS = 128
MAX_MODEL_LEN = 2048           # kept modest -- KV cache is the tight resource
GPU_MEMORY_UTILIZATION = 0.90  # pushed up since weights alone use ~63% of 16GB
# -----------------------------------------------------------------------------


class Submission:

    backend = "vllm"
    model_name = HF_REPO_ID.split("/")[-1]

    def setup(self):
        if HF_TOKEN:
            os.environ["HF_TOKEN"] = HF_TOKEN
        print(f"[vllm] loading {HF_REPO_ID} ...", flush=True)
        t0 = time.time()
        self.tokenizer = AutoTokenizer.from_pretrained(
            HF_REPO_ID, token=HF_TOKEN or None
        )
        print(f"[vllm] tokenizer ready ({time.time() - t0:.1f}s), "
              f"downloading/loading weights next ...", flush=True)
        self.llm = LLM(
            model=HF_REPO_ID,
            quantization=QUANTIZATION,
            max_model_len=MAX_MODEL_LEN,
            gpu_memory_utilization=GPU_MEMORY_UTILIZATION,
            enforce_eager=True,  # skip CUDA graph capture: saves VRAM + startup time
        )
        print(f"[vllm] engine ready ({time.time() - t0:.1f}s total)", flush=True)
        self.sampling = SamplingParams(
            temperature=TEMPERATURE, top_p=TOP_P, max_tokens=MAX_NEW_TOKENS
        )

    def _build_input(self, prompt):
        if getattr(self.tokenizer, "chat_template", None):
            # Unlike Mistral, Qwen's chat template supports a real "system"
            # role turn, so it doesn't need to be folded into the user turn.
            messages = []
            if SYSTEM_PROMPT:
                messages.append({"role": "system", "content": SYSTEM_PROMPT})
            messages.append({"role": "user", "content": prompt})
            return self.tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True
            )
        prefix = (SYSTEM_PROMPT + "\n\n") if SYSTEM_PROMPT else ""
        return f"{prefix}Question: {prompt}\nAnswer:"

    def generate(self, prompt):
        text = self._build_input(prompt)
        outputs = self.llm.generate([text], self.sampling)
        return outputs[0].outputs[0].text.strip()
