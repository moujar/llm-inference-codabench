# =============================================================================
# Starter kit: vLLM backend -- 32B model variant (2x T4, tensor parallel)
# =============================================================================
# Uses Qwen/Qwen2.5-32B-Instruct-AWQ (19.3 GB AWQ weights total). This model
# is too big for a single 16GB T4, but with tensor_parallel_size=2 it's
# sharded across both GPUs: ~9.65 GB of weights per GPU, leaving ~6 GB per
# GPU for KV cache + activations -- a comfortable margin, unlike the 20B
# single-GPU attempt.
#
# REQUIRES: both T4s actually visible to the container (nvidia-smi shows 2
# devices). If you hit the same "NVIDIA Driver was not detected" issue as
# before, fix that first -- this won't run at all without GPU access, let
# alone with 2 GPUs.
# =============================================================================
import os
import time

# NOTE: hf_transfer was removed here on purpose. It downloads with several
# concurrent connections, buffering multiple chunks in host RAM at once.
# On a host that's fine on GPU VRAM but tight on system RAM -- especially
# with tensor_parallel_size=2 spawning a second worker process -- that
# extra buffering is a plausible cause of a silent, traceback-free kill
# (the Linux OOM killer sends SIGKILL, which produces no Python exception
# at all, which matches what was observed: the log just stops mid-download).
# The stock sequential downloader below trades some speed for a much lower
# and more predictable memory footprint.
os.environ.pop("HF_HUB_ENABLE_HF_TRANSFER", None)
os.environ.setdefault("HF_HUB_VERBOSITY", "info")

from huggingface_hub import snapshot_download
from vllm import LLM, SamplingParams
from transformers import AutoTokenizer

# ---- CONFIG -----------------------------------------------------------------
HF_REPO_ID = "Qwen/Qwen2.5-32B-Instruct-AWQ"
QUANTIZATION = "awq"
HF_TOKEN = ""
SYSTEM_PROMPT = "You are a helpful assistant. Answer concisely."
TEMPERATURE = 0.7
TOP_P = 0.9
MAX_NEW_TOKENS = 128
MAX_MODEL_LEN = 3072             # was 4096; engine reported only 3760 tokens fit -- leave margin below that
GPU_MEMORY_UTILIZATION = 0.90    # was 0.85; a bit more room helps since weights are fixed at ~9.1GB/GPU
TENSOR_PARALLEL_SIZE = 2        # shard the model across both T4s
# -----------------------------------------------------------------------------


class Submission:

    backend = "vllm"
    model_name = HF_REPO_ID.split("/")[-1]

    def setup(self):
        if HF_TOKEN:
            os.environ["HF_TOKEN"] = HF_TOKEN
        print(f"[vllm] loading {HF_REPO_ID} across {TENSOR_PARALLEL_SIZE} GPUs ...",
              flush=True)
        t0 = time.time()
        self.tokenizer = AutoTokenizer.from_pretrained(
            HF_REPO_ID, token=HF_TOKEN or None
        )
        print(f"[vllm] tokenizer ready ({time.time() - t0:.1f}s), "
              f"downloading weights next (~19 GB total) ...", flush=True)

        # Explicit staged download with low concurrency and per-file logging.
        # max_workers=2 keeps peak host RAM well below what hf_transfer's
        # multi-connection buffering would use. If this dies again, the log
        # will show the last file that started, instead of going silent.
        local_dir = snapshot_download(
            repo_id=HF_REPO_ID,
            token=HF_TOKEN or None,
            max_workers=2,
            allow_patterns=["*.json", "*.safetensors", "*.txt", "*.model"],
        )
        print(f"[vllm] weights on disk at {local_dir} "
              f"({time.time() - t0:.1f}s), initializing engine ...", flush=True)

        self.llm = LLM(
            model=local_dir,
            quantization=QUANTIZATION,
            max_model_len=MAX_MODEL_LEN,
            gpu_memory_utilization=GPU_MEMORY_UTILIZATION,
            tensor_parallel_size=TENSOR_PARALLEL_SIZE,
            enforce_eager=True,  # skip CUDA graph capture -- saves VRAM on both ranks
        )
        print(f"[vllm] engine ready ({time.time() - t0:.1f}s total)", flush=True)
        self.sampling = SamplingParams(
            temperature=TEMPERATURE, top_p=TOP_P, max_tokens=MAX_NEW_TOKENS
        )

    def _build_input(self, prompt):
        if getattr(self.tokenizer, "chat_template", None):
            # Qwen's chat template supports a real "system" role turn.
            messages = []
            if SYSTEM_PROMPT:
                messages.append({"role": "system", "content": SYSTEM_PROMPT})
            messages.append({"role": "user", "content": prompt})
            return self.tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True
            )
        prefix = (SYSTEM_PROMPT + "\n\n") if SYSTEM_PROMPT else ""
        return f"{prefix}Question: {prompt}\nAnswer:"

    def generate(self, prompt):
        text = self._build_input(prompt)
        outputs = self.llm.generate([text], self.sampling)
        return outputs[0].outputs[0].text.strip()
