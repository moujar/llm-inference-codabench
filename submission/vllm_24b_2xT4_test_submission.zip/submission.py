# =============================================================================
# Starter kit: vLLM backend -- 24B model variant (2x T4, tensor parallel)
# =============================================================================
# Uses stelterlab/Mistral-Small-24B-Instruct-2501-AWQ. This is a smaller
# fraction of the 2x16GB budget than the 32B Qwen model that already worked,
# so there should be noticeably more headroom for KV cache / max_model_len.
#
# Same two things carried over from the 32B fix, since they were real fixes:
#   - explicit staged snapshot_download (low concurrency, per-file logging)
#     instead of hf_transfer, to keep host RAM usage low and predictable
#   - tensor_parallel_size=2 to shard across both T4s
#
# Mistral's chat template does NOT support a separate "system" role (same
# quirk as the 7B Mistral model from earlier) -- the system prompt is
# folded into the user turn instead of sent as its own message.
# =============================================================================
import os
import time

os.environ.pop("HF_HUB_ENABLE_HF_TRANSFER", None)
os.environ.setdefault("HF_HUB_VERBOSITY", "info")

from huggingface_hub import snapshot_download
from vllm import LLM, SamplingParams
from transformers import AutoTokenizer

# ---- CONFIG -----------------------------------------------------------------
HF_REPO_ID = "stelterlab/Mistral-Small-24B-Instruct-2501-AWQ"
QUANTIZATION = "awq"
HF_TOKEN = ""
SYSTEM_PROMPT = "You are a helpful assistant. Answer concisely."
TEMPERATURE = 0.7
TOP_P = 0.9
MAX_NEW_TOKENS = 128
MAX_MODEL_LEN = 4096
GPU_MEMORY_UTILIZATION = 0.85
TENSOR_PARALLEL_SIZE = 2
# -----------------------------------------------------------------------------


class Submission:

    backend = "vllm"
    model_name = HF_REPO_ID.split("/")[-1]

    def setup(self):
        if HF_TOKEN:
            os.environ["HF_TOKEN"] = HF_TOKEN
        print(f"[vllm] loading {HF_REPO_ID} across {TENSOR_PARALLEL_SIZE} GPUs ...",
              flush=True)
        t0 = time.time()
        self.tokenizer = AutoTokenizer.from_pretrained(
            HF_REPO_ID, token=HF_TOKEN or None
        )
        print(f"[vllm] tokenizer ready ({time.time() - t0:.1f}s), "
              f"downloading weights next ...", flush=True)

        local_dir = snapshot_download(
            repo_id=HF_REPO_ID,
            token=HF_TOKEN or None,
            max_workers=2,
            allow_patterns=["*.json", "*.safetensors", "*.txt", "*.model"],
        )
        print(f"[vllm] weights on disk at {local_dir} "
              f"({time.time() - t0:.1f}s), initializing engine ...", flush=True)

        self.llm = LLM(
            model=local_dir,
            quantization=QUANTIZATION,
            max_model_len=MAX_MODEL_LEN,
            gpu_memory_utilization=GPU_MEMORY_UTILIZATION,
            tensor_parallel_size=TENSOR_PARALLEL_SIZE,
            enforce_eager=True,
        )
        print(f"[vllm] engine ready ({time.time() - t0:.1f}s total)", flush=True)
        self.sampling = SamplingParams(
            temperature=TEMPERATURE, top_p=TOP_P, max_tokens=MAX_NEW_TOKENS
        )

    def _build_input(self, prompt):
        if getattr(self.tokenizer, "chat_template", None):
            # Mistral's chat template only accepts alternating user/assistant
            # turns -- no separate "system" role. Fold it into the user turn.
            user_content = (
                f"{SYSTEM_PROMPT}\n\n{prompt}" if SYSTEM_PROMPT else prompt
            )
            messages = [{"role": "user", "content": user_content}]
            return self.tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True
            )
        prefix = (SYSTEM_PROMPT + "\n\n") if SYSTEM_PROMPT else ""
        return f"{prefix}Question: {prompt}\nAnswer:"

    def generate(self, prompt):
        text = self._build_input(prompt)
        outputs = self.llm.generate([text], self.sampling)
        return outputs[0].outputs[0].text.strip()
