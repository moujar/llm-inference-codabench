# =============================================================================
# Starter kit: vLLM backend -- 7B model variant
# =============================================================================
# High-throughput inference. Requires a GPU. Edit the CONFIG block, then submit
# this file together with requirements.txt.
#
# Uses a 4-bit AWQ quantized checkpoint instead of the default SmolLM2-135M:
# a 7B model in full fp16 needs ~14 GB of VRAM for weights alone, which is too
# tight on a 14-16 GB GPU (e.g. a T4) once KV cache and activations are added.
# The AWQ quant needs ~4-5 GB, leaving headroom for both.
# =============================================================================
import os
import time

# Speed up + de-silence the HF Hub download of the (multi-GB) weight files.
# Without this, huggingface_hub's progress bars use carriage-return updates
# that are often swallowed by piped/captured logs -- a slow download then
# looks identical to a genuine hang. hf_transfer also downloads noticeably
# faster via parallel connections.
os.environ.setdefault("HF_HUB_ENABLE_HF_TRANSFER", "1")
os.environ.setdefault("HF_HUB_VERBOSITY", "info")

from vllm import LLM, SamplingParams
from transformers import AutoTokenizer

# ---- CONFIG -----------------------------------------------------------------
HF_REPO_ID = "solidrust/Mistral-7B-Instruct-v0.3-AWQ"
QUANTIZATION = "awq"          # None for unquantized fp16 repos
HF_TOKEN = ""                  # only for PRIVATE / gated repos
SYSTEM_PROMPT = "You are a helpful assistant. Answer concisely."
TEMPERATURE = 0.7
TOP_P = 0.9
MAX_NEW_TOKENS = 128
MAX_MODEL_LEN = 4096
GPU_MEMORY_UTILIZATION = 0.85
# -----------------------------------------------------------------------------


class Submission:

    backend = "vllm"
    model_name = HF_REPO_ID.split("/")[-1]

    def setup(self):
        if HF_TOKEN:
            os.environ["HF_TOKEN"] = HF_TOKEN
        print(f"[vllm] loading {HF_REPO_ID} ...", flush=True)
        t0 = time.time()
        self.tokenizer = AutoTokenizer.from_pretrained(
            HF_REPO_ID, token=HF_TOKEN or None
        )
        print(f"[vllm] tokenizer ready ({time.time() - t0:.1f}s), "
              f"downloading/loading weights next ...", flush=True)
        self.llm = LLM(
            model=HF_REPO_ID,
            quantization=QUANTIZATION,
            max_model_len=MAX_MODEL_LEN,
            gpu_memory_utilization=GPU_MEMORY_UTILIZATION,
            # Skip CUDA graph capture. It adds real startup time (can look
            # like a second, later "hang") and isn't worth it for an
            # 8-prompt ingestion pass -- it only pays off over many calls.
            enforce_eager=True,
        )
        print(f"[vllm] engine ready ({time.time() - t0:.1f}s total)", flush=True)
        self.sampling = SamplingParams(
            temperature=TEMPERATURE, top_p=TOP_P, max_tokens=MAX_NEW_TOKENS
        )

    def _build_input(self, prompt):
        if getattr(self.tokenizer, "chat_template", None):
            # Mistral's chat template only accepts strictly alternating
            # user/assistant turns -- it has no "system" role. A separate
            # system message triggers: "Conversation roles must alternate
            # user/assistant/user/assistant/...". So fold it into the user
            # turn instead of sending it as its own message.
            user_content = (
                f"{SYSTEM_PROMPT}\n\n{prompt}" if SYSTEM_PROMPT else prompt
            )
            messages = [{"role": "user", "content": user_content}]
            return self.tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True
            )
        prefix = (SYSTEM_PROMPT + "\n\n") if SYSTEM_PROMPT else ""
        return f"{prefix}Question: {prompt}\nAnswer:"

    def generate(self, prompt):
        text = self._build_input(prompt)
        outputs = self.llm.generate([text], self.sampling)
        return outputs[0].outputs[0].text.strip()
